g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'

clear
clear

cd
cd $HOME/payload5/.tool
rm -rif sem22
git clone https://github.com/alimaxali/sem22
cd sem22
chmod +x sem.sh
./sem.sh
echo -e "$yellow"


read -p  "(7.6.8 pro) number =====> " ali

wifi(){
cd $HOME/payload5/.tool2/wifi
./wifi.sh



}
hackers(){
cd $HOME/payload5/.tool2/hackers
./hackers.sh




}
root(){
cd $HOME/payload5/.tool2/root
./root.sh




}
virus(){
cd $HOME/payload5/.tool2/virus
./virus.sh




}
whatsapp(){
cd $HOME/payload5/.tool2/whatsapp
./whatsapp.sh




}




ask(){
cd $HOME/payload5/.tool2/ask 
./ask.sh




}



if [ "$ali" -eq "1"  ]; then
	wifi
elif [ "$ali" -eq "2"  ]; then
	hackers
elif [ "$ali" -eq "3"  ]; then
	root
elif [ "$ali" -eq "4"  ]; then
	virus
elif [ "$ali" -eq "5"  ]; then
	whatsapp
elif [ "$ali" -eq "6"  ]; then
	ask
else
echo -e "$red"
figlet -f big "ERROR"
sleep 1
payload2
fi

