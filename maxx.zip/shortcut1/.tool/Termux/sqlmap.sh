f=$HOME/sqlmap
if [ -d $f ];then
echo "It should be deleted first"
sleep 7
payload

else
cd
git clone https://github.com/sqlmapproject/sqlmap.git
cd sqlmap
python2 sqlmap.py
fi
