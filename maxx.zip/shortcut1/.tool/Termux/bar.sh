clear
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
pu='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
chat2(){
echo 'def kk(t):' > .sss.py
echo '   import sys, time' >> .sss.py
echo '   for txt in t + "\n":' >> .sss.py
echo '        sys.stdout.write(txt)' >> .sss.py
echo '        sys.stdout.flush()' >> .sss.py
echo '        time.sleep(9. / 200)' >> .sss.py



echo 'f = "  \033[1;36m   ESC    CTRL   ALT   TAP   UP   END"' >> .sss.py
echo 'y = "\033[1;36m     /       -     HOME  LEFT DOWN  RIGHT"'>> .sss.py
echo 'kk(f)' >> .sss.py
echo 'kk(y)' >> .sss.py
python2 .sss.py

}


ssss(){
cd
rm -rif .termux
mkdir .termux
cd .termux
echo "extra-keys = [['ESC','CTRL','ALT','TAB','UP','END'],['/','-','HOME','LEFT','DOWN','RIGHT']]" >> termux.properties
echo -e "$y ESC$g ✔"
sleep 0.2
echo -e "$y CTRL$g ✔"
sleep 0.2
echo -e "$y ALT$g ✔"
sleep 0.2
echo -e "$y TAP$g ✔"
sleep 0.2
echo -e "$y UP$g ✔"
sleep 0.5
echo -e "$y END$g ✔"
sleep 0.5
echo -e "$y / $g ✔"
sleep 0.4
echo -e "$y - $g ✔"
sleep 0.4
echo -e "$y HOME$g ✔"
sleep 0.5
echo -e "$y LEFT$g ✔"
sleep 0.5
echo -e "$y DOWN$g ✔"
sleep 0.5
echo -e "$y RIGHT$g ✔"
sleep 0.2
termux-reload-settings
payload
}



chat2
echo -e "$p"
read -p "-----y/n---->" aa
if [ "$aa" = "y" ]; then
ssss
else
payload
fi
