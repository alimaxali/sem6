#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install





echo -e "      $red                                    [00]back"
echo -e "$reset"
sleep 0.1
echo "             [1]Change the shape of Termux📟"

sleep 0.1
echo "             [2]The shape of the skull Termux📟"
sleep 0.1
echo "             [3]The shape of the skull(2) Termux📟"
sleep 0.1
echo "             [4]Download Tool-x⬇️ "
sleep 0.1
echo "             [5]Download sqlmap⬇️ "
sleep 0.1
echo "             [6]Download beef⬇️ "
sleep 0.1
echo "             [7]Download A-Rat⬇️ "
sleep 0.1
echo "             [8]Download IPGeoLocation⬇️ "
sleep 0.1
echo "             [9]Download Easyhack⬇️ "
sleep 0.1
echo "             [10]Download netflix hack⬇️ "
sleep 0.1
echo "             [11]Help bar⬇️ "
echo -e "$green"
