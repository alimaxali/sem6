def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 200)
f = "  \033[1;36m   ESC    CTRL   ALT   TAP   UP   END"
y = "\033[1;36m     /       -     HOME  LEFT DOWN  RIGHT"
kk(f)
kk(y)
