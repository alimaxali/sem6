import requests,json,hashlib
import os
global token
W="\033[0m"
R="\033[91m"
G="\033[92m"
Y="\033[93m"
B="\033[94m"
RS="\033[95m"

def sem3():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 h = " \033[92mPlease Wait"
 kk(h)
#------------------


def sem2():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 h = "\033[92m {1}\033[95m pack"
 w = "\033[92m {2}\033[95m logout"
 e = "\033[92m {3}\033[95m exit"
 kk(h)
 kk(w)
 kk(e)
#------------------
def error():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 k = "\033[91m failed!"
 kk(k)

#------------------
def sem():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 250)
 q = "\033[92m {1}\033[95m dump friends name&id "
 w = "\033[92m {2}\033[95m dump friends emails "
 e = "\033[92m {3}\033[95m dump friends phones"
 r = "\033[92m {4}\033[95m dump friends birthdays"
 t = "\033[92m {5}\033[95m id information"
 y = "\033[92m {6}\033[95m post"
 u = "\033[92m {7}\033[95m edit post"
 i = "\033[92m {8}\033[95m delete post"
 o = "\033[92m {9}\033[95m comment"
 p = "\033[92m {10}\033[95m logout "
 a = "\033[92m {11}\033[95m exit "
 kk(q)
 kk(w)
 kk(e)
 kk(r)
 kk(t)
 kk(y)
 kk(u)
 kk(i)
 kk(o)
 kk(p)
 kk(a)
#---------------------

def emaill():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 k = " \033[92mEmail or Phone or id"
 kk(k)

#------------------
def passs():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 k = "\033[92m password"
 kk(k)

#------------------

def main():
 def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
 h = "     \033[1;34m payload5 in facebook \n"
 kk(h)


#################
def id():



	emaill()
	id=raw_input("=======> ")
	passs()
	pwd=raw_input("=======> ")
	API_SECRET = '62f8ce9f74b12f84c123cc23437a4a32'
	sig= 'api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail='+id+'format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword='+pwd+'return_ssl_resources=0v=1.0'+API_SECRET
 	data = {"api_key":"882a8490361da98702bf97a021ddc14d","credentials_type":"password","email":id,"format":"JSON", "generate_machine_id":"1","generate_session_cookies":"1","locale":"en_US","method":"auth.login","password":pwd,"return_ssl_resources":"0","v":"1.0"}
	x=hashlib.new("md5")
	x.update(sig)
	a=x.hexdigest()
	data.update({'sig':a})
	return data
#########################
def get_token():
	data=id()
	url = "https://api.facebook.com/restserver.php"
	try:
		r=requests.get(url,params=data)
		z=json.loads(r.text)
		cookie=open('cookie','w')
		cookie.write(z['access_token'])
		cookie.close()
		print G+'successful'+W
		menu2()
	except KeyError:
		os.remove("cookie")
		error()
		menu1()
###################
def cookie():
	    global token
	    try:
	    	cookie=open("cookie","r")
	    	token=cookie.read()
	    	cookie.close()
	    	menu2()
	    except:
	    	menu1()
###########################
def menu1():
		get_token()


#################	
def menu2():

	sem()
	chose2=raw_input("===========>"+R)
	if chose2== "1":
		sem3()
		dump_friends()
		menu3()
	elif chose2=="2":
		sem3()
		dump_emails()
		menu3()
	elif chose2=="3":
		sem3()
		dump_phones()
		menu3()
	elif chose2=="4":
		sem3()
		dump_dates()
		menu3()
	elif chose2=="5":
			id=raw_input(W+"inter target id:"+R)
			sem3()
			id_information(id)
			menu3()
	elif chose2=="6":
			post_id=raw_input(W+"inter target id:"+R)
			msg=raw_input(W+"inter the message: "+R)
			sem3()
			post(post_id,msg)
			print G+"successful posting"+W
			menu3()
	elif chose2=="7":
		post_id=raw_input(W+"inter post id:"+R)
		msg=raw_input(W+"inter the message: "+R)
		sem3()
		edit_post(post_id,msg)
		print G+"successful post edit"+W
		menu3()
	elif chose2=="8":
		post_id=raw_input(W+"inter post id:"+R)
		sem3()
		delete_post(post_id)
		print G+"successful post delete"+W
		menu3()
	elif chose2=="9":
		post_id=raw_input(W+"inter post id:"+R)
		msg=raw_input(W+"inter the message: "+R)
		sem3()
		comment(post_id,msg)
		print G+"successful comment"+W
		menu3()
	elif chose2=="10":
		print " "+W
		os.remove("cookie")
				
	elif chose2=="11":
		print " "+W
	else:
		print "out of menu:"
		menu2()		
######################
def menu3():
	sem2()
 	chose3=raw_input(W+"=>: "+R)
	if chose3=="1":
		menu2()
	elif chose3=="2":
		os.remove("cookie")
		exit()
	elif chose3=="3":
		print W+""
	else:
		print R+"out of menu:"+W
		menu3()
##########################		
def dump_friends():
	global token
	
	url= "https://graph.facebook.com/me/friends"
	r=requests.get(url+"?access_token="+token)
	z=json.loads(r.text)
	for i in z["data"]:
		try:
			print W+i["name"]+" : "+G+i["id"]+W
		except:
			pass
	
          
####################
def dump_emails():
	global token
	url= "https://graph.facebook.com/"
	r= requests.get(url+"me/friends?access_token="+token)
	z=json.loads(r.text)
	for i in z["data"]:
		try:
			l = requests.get(url+i["id"]+"?access_token="+token)
			email=json.loads(l.text)
			print W+i["name"]+" : "+G+email["email"]+W
		except:
			pass
	
#####################
def dump_phones():
	global token
	url= "https://graph.facebook.com/"
	r =requests.get(url+"me/friends?access_token="+token)
	z=json.loads(r.text)
	for i in z["data"]:
		try:
			l = requests.get(url+i["id"]+"?access_token="+token)
			phone=json.loads(l.text)
			print W+i["name"]+" : "+G+phone["mobile_phone"]+W
		except:
			pass
	
######################
def dump_dates():
	global token
	url= "https://graph.facebook.com/"
	r=requests.get(url+"me/friends?access_token="+token)
	z=json.loads(r.text)
	for i in z["data"]:
		try:
			l = requests.get(url+i["id"]+"?access_token="+token)
			email=json.loads(l.text)
			print W+i["name"]+" : "+G+email["birthday"]+W
		except:
			pass
	
######################
def id_information(id):
	global token
	
	url= "https://graph.facebook.com/"+id
	r= requests.get(url+"?access_token="+token)
	z=json.loads(r.text)
	try:
			print W+"Name : "+G+z["name"]+W
	except: print W+"Name : "+G+"not found"
	try:
			print W+"Email : "+G+z["email"]+W
	except: print W+"Email : "+G+"not found"
	try:
			print W+"Phpne : "+G+z["mobile_phone"]+W
	except: print W+"Phone : "+G+"not found"
	try:
			print W+"Birthday : "+G+z["birthday"]+W
	except: print W+"Birthday : "+G+"not found"
	
#######################
def post(post_id,msg):
	global token
	url="https://graph.facebook.com/"+post_id+"/feed"
	data= {"access_token":token,"message":msg}
	r=requests.post(url,json=data)
	
##############
def edit_post(post_id,msg):
	global token
	url="https://graph.facebook.com/"+post_id
	data= {"access_token":token,"message":msg}
	r=requests.post(url,json=data)
	
#######################
def delete_post(post_id):
	global token
	url="https://graph.facebook.com/"+post_id
	data= {"access_token":token,"method":"delete"}
	r=requests.post(url,json=data)
	
#######################
def comment(post_id,msg):
	global token
	url="https://graph.facebook.com/"+post_id+"/comments"
	data= {"access_token":token,"message":msg}
	r=requests.post(url,json=data)
	
######################
if __name__ ==	'__main__':
	main()
	cookie()
