#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


echo -e "$g+++++++++++++++>$p[Please Wait]$g<+++++++++++++++++"
cd
git clone https://github.com/rapid7/metasploit-framework
bundle install

clear
echo -e "$g+++++++++++++++>$p[Please Wait]$g<+++++++++++++++++"
gem install crass -v '1.0.4' --source 'https://rubygems.org/'
cd
cd metasploit-framework
bundle update nokogiri
echo -e "$g++++++++++>$p[end Download 
metasploit]$g<++++++++++++"
sleep 1
payload.sh
