#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

echo -e "      $red                                    [00]back"
echo -e "$yellow"
echo "           [1]open ngrok http 🌐"
sleep 0.1
echo "           [2]open ngrok tcp  🌐"
sleep 0.1
echo "           [3]Download ngrok ⬇️ "
sleep 0.1
echo -e "$green"
