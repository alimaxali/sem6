clear

#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


cd




rm -rif /sdcard/payload5.zip

rm -rif /sdcard/*/payload5.zip

rm -rif /sdcard/*/*/payload5.zip

rm -rif /sdcard/*/*/*/payload5.zip

rm -rif /sdcard/*/*/*/*/payload5.zip

rm -rif /sdcard/payload6.zip

rm -rif /sdcard/*/payload6.zip

rm -rif /sdcard/*/*/payload6.zip

rm -rif /sdcard/*/*/*/payload6.zip

rm -rif /sdcard/*/*/*/*/payload6.zip



cd $HOME/payload5/.tool/sem2
bash tool.sh

cd $HOME/payload5
rm index.html
wget ifconfig.me
clear
chat(){
echo 'def kk(t):' > .sssss.py
echo '   import sys, time' >> .sssss.py
echo '   for txt in t + "\n":' >> .sssss.py
echo '        sys.stdout.write(txt)' >> .sssss.py
echo '        sys.stdout.flush()' >> .sssss.py
echo '        time.sleep(9. / 240)' >> .sssss.py


echo 'h = "              \033[1;33m[\033[1;32m*\033[1;33m] you welcome in {\033[1;36mpauload6\033[1;33m} py [\033[1;32mali.max\033[1;33m] "' >> .sssss.py
echo 'kk(h)' >> .sssss.py
python2 .sssss.py

}
chat2(){
echo 'def kk(t):' > .ssss.py
echo '   import sys, time' >> .ssss.py
echo '   for txt in t + "\n":' >> .ssss.py
echo '        sys.stdout.write(txt)' >> .ssss.py
echo '        sys.stdout.flush()' >> .ssss.py
echo '        time.sleep(4. / 240)' >> .ssss.py



echo 'f = "    \033[1;32m [\033[1;33m30\033[1;32m] Continue my account {\033[1;34mFacebook\033[1;32m}"' >> .ssss.py
echo 'y = "     \033[1;32m[\033[1;33m40\033[1;32m] Follow my channel {\033[1;31mYouTube\033[1;32m}"' >> .ssss.py
echo 'kk(f)' >> .ssss.py
echo 'kk(y)' >> .ssss.py
python2 .ssss.py

}
echo -e "$g"
figlet  -f big "           payload 6  "
chat
echo -e "$cyan"
echo -e "                _____________________"
sleep 0.1
echo -e "               ($blue  ali $cyan ##### $red  max $cyan  )"
sleep 0.1
echo -e '            /_~~~~~~~~~~~~~~~~~~~~~~~~~_\'
sleep 0.1
echo -e '          /~                             ~\'
sleep 0.1
echo -e '        .~             '$g'payload6'$cyan'             ~'
sleep 0.1
echo -e '    ()\/_____                           _____\/()'
sleep 0.1
echo -e '   .-``      ~~~~~~~~~~~~~~~~~~~~~~~~~~~     ``-.'      
sleep 0.1
echo -e '.-~              ____'$y'[90]helpℹ️'$cyan'____               ~-.'  
sleep 0.1
echo -e '`~~/~~~~~~~~~~~~TTTTTTTTTTTTTTTTTTTT~~~~~~~~~~~~\~~`'
sleep 0.1
echo -e '| | |'$g' #### #### '$cyan'|| | | | [] | | | || '$g'#### ####'$cyan' | | |'  
sleep 0.1
echo -e ';__\|___________|++++++++++++++++++|___________|/__;'
sleep 0.1
echo -e ' (~~====___________________________________====~~~)'
sleep 0.1
echo -e '  \------_____________[CHIP 911]__________-------/'
sleep 0.1
echo -e '     |      ||         ~~~~~~~~       ||      |'
sleep 0.1
echo -e '      \_____/                          \_____/'


echo -e "                $blue p $green a $reset y $purple l $cyan o $yellow a $green d"
echo ""
echo ""
chat2
echo -e "$green+________________________________________________________+"
echo -e "$cyan|  [1] metasploit ⚔️|  $blue  [2] nmap 🌎| $purple  [3] dos attack ⛔ |             "
echo -e "$yellow|  [4]   ngrok 🌐  |  $red  [5] virus ☢️️|  $reset [6]   Termux 📟   |    "
echo "     "
echo -e "$purple|  [7] facebook   $blue      [8] Encrypt   $cyan [9]   tool root   |"
echo -e " $green          --------------------------------------"
echo -e "                     $red [$cyan"$cyan"1212$red]password"
echo -e "                     $red [$cyan"$cyan"6666$red]Hide (faile/phato/Video/...)"
echo -e "                     $red [$cyan"$cyan"7777$red]Dump area"
echo -e "              $red [$cyan"$cyan"8888$red]Backup photo/Video"
echo -e "              $red [$cyan"$cyan"9999$red]Backup photo/Video ($cyan root$red )"



echo -e " $red "
echo -e " [00] Exit           $green                          [99] update"
#echo -e "$green"
echo -e "$cyan"
echo -e "|---{$yellow my ip$cyan }---| "
cat index.html
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
#echo -e "$green "


